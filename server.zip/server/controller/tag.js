const addTag = async (req, res) => {

}

const removeTag = async (req, res) => {

}

const editTag = async (req, res) => {

}

const getAllTag = async (req, res) => {

}

export { addTag, removeTag, editTag, getAllTag };
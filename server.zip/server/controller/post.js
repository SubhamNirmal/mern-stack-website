const addPost = async (req, res) => {

}

const removePost = async (req, res) => {

}

const editPost = async (req, res) => {

}

const getAllPost = async (req, res) => {

}

export { addPost, removePost, editPost, getAllPost };